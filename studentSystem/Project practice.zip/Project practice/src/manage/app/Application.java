package manage.app;

import manage.gui.FindPasswod;
import manage.gui.LoginFrame;
import manage.gui.MainFrame;
import manage.gui.MainFrameStudent;
import manage.gui.MainFrameTeacher;
import manage.studentgui.Findpasswd3;
import manage.studentgui.RegisterFrame3;
import manage.teachergui.FindPassword2;
import manage.teachergui.RegisterFrame2;





public class Application {
	 /**
	    * ��¼�û���ʶ��
	    */
	    public static int id;
	    /**
	    * ��¼�û���
	    */
	    public static String username;
	    /**
	    * ��¼����
	    */
	    public static LoginFrame loginFrame;
	    /**
	    * ������
	    */
	    
	    public static MainFrameStudent mainFrameStudent; 
	    public static MainFrameTeacher mainFrameTeacher;
	    public static MainFrame mainFrame;
	    /**
	    * ע�ᴰ��
	    */
	    public static RegisterFrame3 registerFrame3;
	    public static RegisterFrame2 registerFrame2;
	    
	    //�һ����봰��
	    public static FindPasswod findPasswod1;
	    public static FindPassword2 findPassword2;
	    public static Findpasswd3 findpasswd3;
	    
	    
		
		 
}
